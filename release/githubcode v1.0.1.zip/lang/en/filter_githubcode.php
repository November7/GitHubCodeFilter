<?php
$string['filtername'] = 'GitHub Code';
$string['pluginname'] = 'GitHub Code Filter';
$string['language'] = 'Default language for highlight.js';
$string['theme'] = 'Default theme';
$string['linenumbers'] = 'Enable line numbers';