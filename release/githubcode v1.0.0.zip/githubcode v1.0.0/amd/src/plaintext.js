// Info:
// keywords: max. 4 groups
// ver: 1.0 [2025.12.06] 

define([], function () {
    return {
            ver: "1.0",
            langname: 'Plain Text',
            casesensitive: {},
            keywords: {},
            number: '[0-9]+',
            text: ['"','\''],
            intxt: 'lLuU',
            realxt: 'fF',
            comment: ['\\/\\/','#'],
            multicomment: [] 
        };
    });