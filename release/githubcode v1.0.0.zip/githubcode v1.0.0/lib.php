<?php
defined('MOODLE_INTERNAL') || die();

function filter_githubcode_page_config($page) {
    //...
}